<?php $__env->startSection('content'); ?><br>
<div class="row">
    <div class="col-lg-3">
    <img src="<?php echo e(asset('storage/images/category_images/'.$category->category_image)); ?>" alt="">
    </div>
    <div class="col-lg-9">
        <div class="col-lg-12 ">
            <div class="card">
            <h5 class="card-header"><?php echo e($category->category_name); ?></h5>
                <div class="card-body">
                    <h5 class="card-title">About This Category</h5>
                <p class="card-text"><?php echo e($category->category_description); ?></p>
                    <a href="/admin/routes" class="btn btn-primary">Go Back</a>
                </div>

        </div>
             
        </div>
    </div>

</div>
<h3 class="text-center">Products in this category:</h3><br><br>
<div class="row">
    <?php if(count($products)>0): ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header">
                 <?php echo e($product->product_name); ?>

                </div>
                <img class="card-img-top" src="<?php echo e(asset('storage/images/product_images/'.$product->product_image)); ?>" alt="">
                <div class="card-body">
                    <h4 class="card-title">KSHs <?php echo e($product->product_price); ?></h4>
                    <p class="card-text"><?php echo e($product->product_description); ?></p>
                </div>
                <div class="card-footer text-muted">
                    
                </div>
            </div>    
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
</div>
    
    


      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\content_creation\courses\mpesa\resources\views/products_categorywise.blade.php ENDPATH**/ ?>