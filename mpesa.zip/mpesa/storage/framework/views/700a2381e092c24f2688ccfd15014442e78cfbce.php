<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 col-lg-offset-2 col-md-6 col-md-offset-3">
            <h3>Add Category</h3>
            <?php echo Form::open(array('action' => 'CategoryController@store','method' => 'POST','enctype'=>'multipart/form-data')); ?>

            <div class="form-group">
                <?php echo e(Form::label('category_name', 'Category Name')); ?>

                <?php echo e(Form::text('category_name', '', ['class'=>'form-control', 'placeholder'=>'Enter Category Name'])); ?>

            
            </div>
            
            <div class="form-group">
                <?php echo e(Form::label('category_description', 'Category Description')); ?>

                <?php echo e(Form::textarea('category_description', '', ['class'=>'form-control'])); ?>

            </div>
            
            <div class="form-group">
                <?php echo e(Form::label('category_image', 'Category Image')); ?>

                <?php echo e(Form::file('category_image', ['class'=>'form-control btn btn-sm btn-success'])); ?>

            </div>
            
            <div class="form-group">
                <?php echo e(Form::submit('Add Category', ['class'=>'btn btn-sm btn-success'])); ?>

            </div>
            
            <?php echo Form::close(); ?>

    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\content_creation\courses\mpesa\resources\views/admin/create_categories.blade.php ENDPATH**/ ?>