<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 col-lg-offset-2 col-md-6 col-md-offset-3">
            <h3>Add Product</h3>
            <?php echo Form::open(array('action' => 'ProductController@store','method' => 'POST','enctype'=>'multipart/form-data')); ?>

<div class="form-group">
<?php echo e(Form::label('product_name', 'Product Name')); ?>

<?php echo e(Form::text('product_name', '', ['class'=>'form-control', 'placeholder'=>'e.g HP Laptop'])); ?>


</div>

            <div class="form-group">
                <?php echo e(Form::label('product_price', 'Product price')); ?>

                <?php echo e(Form::number('product_price', '', ['class'=>'form-control','placeholder'=>'e.g 500'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('product_quantity', 'Product Quantity')); ?>

                <?php echo e(Form::number('product_quantity', '', ['class'=>'form-control','placeholder'=>'e.g 5'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('product_location', 'Product Location')); ?>

                <?php echo e(Form::text('product_location', '', ['class'=>'form-control','placeholder'=>'e.g Nairobi CBD'])); ?>

            </div>

            <div class="form-group">
            <input type="hidden" name="user_id" class="form-control" value="<?php echo e(Auth()->user()->id); ?>" hidden >
        
            </div>

            <div class="form-group">
                <label for="sel1">Select Product Category:</label>
                    <select class="form-control" id="sel1" name="category_id">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
            </div>

            <div class="form-group">
                <?php echo e(Form::label('product_description', 'Product Description')); ?>

                <?php echo e(Form::textarea('product_description', '', ['class'=>'form-control'])); ?>

            </div>
            
            <div class="form-group">
                <?php echo e(Form::label('product_image', 'Product Image')); ?>

                <?php echo e(Form::file('product_image', ['class'=>'form-control btn btn-sm btn-success'])); ?>

            </div>
            
            <div class="form-group">
                <?php echo e(Form::submit('Add product', ['class'=>'btn btn-sm btn-success'])); ?>

            </div>
            
            <?php echo Form::close(); ?>

    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\content_creation\courses\mpesa\resources\views/admin/create_products.blade.php ENDPATH**/ ?>