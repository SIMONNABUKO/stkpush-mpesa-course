<?php $__env->startSection('title', '|Products List Page'); ?>

<?php $__env->startSection('description', 'Sir-erics- The list of the products onsale on our site'); ?>

<?php $__env->startSection('content'); ?>
<!-- Portfolio Projects -->
<div class="container marginbot50">
	<div class="row">
		<div class="col-lg-12">
			<p class="h3">Product Details</p>

			<table class="table table-striped table-inverse table-responsive">
				<thead class="thead-inverse">
					<tr>
						<th>Name</th>
						<th>Price</th>
						<th>Quantity</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php if(count($cart_content)>0): ?>
					<?php $__currentLoopData = $cart_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td scope="row"><?php echo e($item->name); ?></td>

						<td><?php echo e($item->price); ?></td>
						<td><?php echo e($item->qty); ?></td>
						<td><a href="/item/remove/<?php echo e($item->rowId); ?>"><i class="fa fa-trash"></i></a></td>
					</tr>
					<tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>

				</tbody>
			</table>
			<div class="d-flex">
				<h2>Cart Total: <?php echo e($total); ?></h2>
				<?php if(count($cart_content)>0): ?>
				<a href="/checkout" class="btn btn-primary ml-auto">Checkout</a>
				<?php endif; ?>

				<a href="/admin/product/index" class="btn btn-primary ml-auto">Continue Shopping</a>
			</div>





		</div>
	</div>
</div>
<script>
	$(document).ready(function() {
		alert('jQuery is working here!');
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\content_creation\courses\mpesa\resources\views/cart/index.blade.php ENDPATH**/ ?>